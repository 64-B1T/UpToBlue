package com.example.notcharles.uptoblue;

import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import java.util.ArrayList;

public class DevicePermissions extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_WRITE_SETTINGS = 0;
    private static final int MY_PERMISSIONS_REQUEST_READ_SMS = 1;
    private static final int MY_PERMISSIONS_REQUEST_ANSWER_PHONE_CALLS = 2;
    private static final int MY_PERMISSIONS_REQUEST_VIBRATE = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_permissions);
    }


    public void onCheckboxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();

        switch(view.getId()) {
            case R.id.brightnessControl:
                if (checked) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.WRITE_SETTINGS)
                            != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.WRITE_SETTINGS},
                                MY_PERMISSIONS_REQUEST_WRITE_SETTINGS);
                    }
                }
                break;

            case R.id.volumeControl:
                //DO NOTHING
                //Setting the media volume to 0 requires no permissions
                break;

            case R.id.smsControl:
                if (checked) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.VIBRATE)
                            != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.VIBRATE},
                                MY_PERMISSIONS_REQUEST_VIBRATE);
                    }
                }
                break;

            case R.id.callControl:
                if (checked) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.VIBRATE)
                            != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.VIBRATE},
                                MY_PERMISSIONS_REQUEST_VIBRATE);
                    }
                }
                break;

            default:
                //SHOULD NEVER HAPPEN
                throw (new RuntimeException("What even happened?"));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        switch(requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_SETTINGS:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                }
                else {
                    ((CheckBox)findViewById(R.id.brightnessControl)).setChecked(false);
                }
                break;

            case MY_PERMISSIONS_REQUEST_READ_SMS:
                //TODO NOT IMPLEMENTED
                break;

            case MY_PERMISSIONS_REQUEST_ANSWER_PHONE_CALLS:
                //TODO NOT IMPLEMENTED
                break;

            case MY_PERMISSIONS_REQUEST_VIBRATE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                }
                else {
                    ((CheckBox)findViewById(R.id.smsControl)).setChecked(false);
                    ((CheckBox)findViewById(R.id.callControl)).setChecked(false);
                }
                break;

            default:
                //SHOULD NEVER HAPPEN
                throw (new RuntimeException("What even happened?"));
        }
    }
}
